<?php

return [
    'previous' => '&laquo; Vorige',
    'sidebar' => [
        'account_settings' => 'Account instellingen',
        'files' => 'Bestandsbeheer',
        'manage' => 'Beheer server',
        'overview' => 'Server overzicht',
        'server_controls' => 'Server beheer',
    ],
];
