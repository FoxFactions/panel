<?php

return [
    'password' => 'Password',
    'reset' => 'La tua password è stata reimpostata!',
    'token' => 'Il token del reset di questa password è invalido.',
];
