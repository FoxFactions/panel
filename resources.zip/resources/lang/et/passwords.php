<?php

return [
    'password' => 'Salasõna',
    'token' => 'Teie salasõna taastamis token on vale',
    'user' => 'Me ei leia kasutajat selle e-maili aadressiga',
];
