<?php

return [
    'password' => 'Parolă',
    'reset' => 'Parola ta a fost resetată!',
    'sent' => 'Ți-am trimis pe e-mail link-ul de resetare al parolei!',
    'token' => 'Token-ul de resetare parolă este invalid.',
    'user' => 'Nu am putut găsi un utilizator cu acest e-mail.',
];
