<?php

return [
    'password' => 'Las contraseñas tienen que tener por lo menos 6 caracteres y la confirmación debe de coincidir.',
    'reset' => 'Tu contraseña ha sido restaurada!',
    'sent' => 'Le hemos enviado un correo de cambio de contraseña!',
    'token' => 'El código de cambio de contraseña es inválido.',
    'user' => 'No podemos encontrar un usuario con ese nombre.',
];
